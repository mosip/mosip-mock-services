The libpkcs11-proxy.so.0.1 has to be copied to the dockers that need access to soft hsm. 
 Please copy this library as libpkcs11-proxy.so to the /usr/local/lib/softhsm
